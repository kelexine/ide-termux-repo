/*
 * This file is auto-generated. Modifications will be lost.
 *
 * See https://android.googlesource.com/platform/bionic/+/master/libc/kernel/
 * for more information.
 */
#ifndef __ASM_AUXVEC_H
#define __ASM_AUXVEC_H
#define AT_SYSINFO_EHDR 33
#define AT_MINSIGSTKSZ 51
#define AT_VECTOR_SIZE_ARCH 2
#endif
