#ifndef ISL_UNION_SET_TYPE_H
#define ISL_UNION_SET_TYPE_H

#include <isl/union_map_type.h>

#endif
