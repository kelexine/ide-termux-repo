#!/data/data/com.itsaky.androidide/files/usr/bin/sh

echo "$@"
